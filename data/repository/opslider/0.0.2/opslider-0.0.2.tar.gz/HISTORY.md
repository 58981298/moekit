# History

---

## 0.0.2

`new` It is the first version of opslider.
