# opslider [![spm version](http://spmjs.io/badge/opslider)](http://spmjs.io/package/opslider)

---

An awesome spm package!

---

## Install

```
$ spm install opslider --save
```

## Usage

```js
var opslider = require('opslider');
// use opslider
```
