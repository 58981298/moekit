# opslide [![spm version](https://moekit.timo.today/badge/opslide)](https://moekit.timo.today/package/opslide)

---

single page slider for mobile and wechat

## Install

```
$ spm install opslide --save
```

## Usage

```js
var opslide = require('opslide');
// use opslide
```
