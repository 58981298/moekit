# 演示文档

---

````javascript
seajs.use('index', function(querystring){

});
````
