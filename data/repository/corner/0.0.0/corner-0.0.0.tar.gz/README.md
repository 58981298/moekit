# corner [![spm version](https://moekit.timo.today/badge/corner)](https://moekit.timo.today/package/corner)

---



## Install

```
$ spm install corner --save
```

## Usage

```js
var corner = require('corner');
// use corner
```
