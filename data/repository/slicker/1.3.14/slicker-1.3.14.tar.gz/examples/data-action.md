# data-action API使用
---

在HTML标签上添加`data-action`属性以实现快捷功能绑定。

+ `next` 切换下一张

+ `prev` 切换上一张