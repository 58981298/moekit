
require('./src/calendar.css');
module.exports = require('./src/calendar');
