  var $ = jQuery;
  $.ajaxPrefilter(function(options, origOptions, jqXHR) {
    if (options.iframe) {
      options.originalURL = options.url;
      return "iframe";
    }
  });
  // add transport
  $.ajaxTransport("iframe", function(options, origOptions, jqXHR) {
    return {
      send: function(headers, completeCallback) {
        // create a hidden form to simulate submit
        var $form = $('<form id="form" target="iframe"></form>')
          .attr('method', options.type || 'GET')
          .attr('action', options.url)
          .append("<input type='hidden' value='IFrame' name='X-Requested-With' />");

        // append inputs according to ajax::option.data
        if (typeof origOptions.data === 'object') {
          for (var one in origOptions.data) {
            $('<input type="hidden"/>').attr('name', one).val(origOptions.data[one]).appendTo($form);
          }
        }

        $form.appendTo('body');

        var $iframe = $('<iframe id="iframe" name="iframe" style="display:none;"></iframe>').appendTo('body');

        $iframe.one('load', function() {
          $iframe.one('load', function() {
            setTimeout(function() {
              var $document = $iframe.contents().get(0);
              var content = $document.getElementsByTagName('textarea')[0].value;
              completeCallback(200, 'OK', {
                text: content,
                iframe: content
              }, 'Content-Type: "application/json"');
              $('#iframe,#form').remove();
            }, 0);
          });
          $('#form').submit();
        });
        $iframe.get(0).src = "javascript:void((function(){document.open();document.domain='" + document.domain + "';document.close()})())";
      },
      abort: function() {
        $('#iframe,#form').remove();
      }
    }
  });
  // setup converters
  jQuery.ajaxSetup({
    converters: {
      "iframe json": jQuery.parseJSON,
      "iframe text": window.String
    }
  });
  return jQuery;
