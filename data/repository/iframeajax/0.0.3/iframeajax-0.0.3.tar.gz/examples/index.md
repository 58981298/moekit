# 演示文档

---

<script src="http://scdn.bozhong.com/source/common/js/jquery.min.js"></script>
<script src="../src/iframeAjax.js"></script>

<form action="http://127.0.0.1:8005" method="GET">
    <input type="submit" value="提交" id="submit">
</form>


````javascript
$(function(){
document.domain='';
    $('#submit').click(function(e){
        e.preventDefault();
        $.ajax({
        type:'get',
        url:'http://127.0.0.1:8005/api.html',
        iframe:true
        });
    });
});
````
