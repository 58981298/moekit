# History

---

## 1.1.0

`tag:changed` 去除 module 信息，seajs 也已经去掉这个 API 了 [#1](https://github.com/aralejs/class/issues/1)

## 1.0.0

正式版本