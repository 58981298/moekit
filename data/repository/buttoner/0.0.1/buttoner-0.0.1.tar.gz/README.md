# buttoner

---

[![spm version](http://spmjs.io/badge/buttoner)](http://spmjs.io/package/buttoner)

An awesome spm package!

---

## Install

```
$ spm install buttoner --save
```

## Usage

```js
var buttoner = require('buttoner');
// use buttoner
```

## Api

Here is more details.

