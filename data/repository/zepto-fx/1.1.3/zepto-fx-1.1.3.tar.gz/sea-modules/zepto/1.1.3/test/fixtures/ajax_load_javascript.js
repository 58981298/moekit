window.testValue = 1;
