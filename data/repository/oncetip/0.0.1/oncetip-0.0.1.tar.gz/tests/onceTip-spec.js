define(function(require) {

  var onceTip = require('onceTip');

  describe('onceTip', function() {

    it('normal usage', function() {

    });
  });

});
