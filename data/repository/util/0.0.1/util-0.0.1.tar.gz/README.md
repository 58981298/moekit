# util

---

[![spm version](http://spmjs.io/badge/util)](http://spmjs.io/package/util)

An awesome spm package!

---

## Install

```
$ spm install util --save
```

## Usage

```js
var util = require('util');
// use util
```

## Api

Here is more details.

