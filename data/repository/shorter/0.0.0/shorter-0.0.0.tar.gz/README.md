# shorter [![spm version](http://spmjs.io/badge/shorter)](http://spmjs.io/package/shorter)

---

This module simply uses Weibo's short-url API.


## Install

```
$ spm install shorter --save
```

## Usage

```js
var shorter = require('shorter');
// use shorter, check the demo
shorter(url,successCallback,errorCallback);
```
