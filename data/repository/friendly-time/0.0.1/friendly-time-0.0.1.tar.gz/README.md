# friendly-time

---

[![spm version](http://moekit.com/badge/friendly-time)](http://spmjs.io/package/friendly-time)

如果只是要实现相对时间计算，而不想要引用庞大的 `moment`的话，就用这个简单的函数吧。

---



## Usage

```js
var friendlyTime = require('friendly-time');
friendTime(new Date());
```



