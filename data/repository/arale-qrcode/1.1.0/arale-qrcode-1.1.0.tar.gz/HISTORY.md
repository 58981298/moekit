# History

---

## 1.1.0

`improved` 升级到 spm@3.x 规范。

## 1.0.3

`tag:improved` 性能优化

## 1.0.2

`tag:improved` 性能优化

## 1.0.1

`tag:improved` 优化代码

## 1.0.0

第一个版本
