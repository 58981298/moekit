
module.exports = require('./src/qrcode.js');
