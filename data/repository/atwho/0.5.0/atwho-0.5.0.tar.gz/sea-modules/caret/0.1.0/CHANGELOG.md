### v0.1.0

* b1f8f53 - fix Mirror div does not reset its CSS
* e88e40e - fix Bad positioning in long words
* 37d4c5e - disable auto decovery iframe

### v0.0.7

* cf94271 - Added suport for .caret(pos, 0) - Nicolas Donna
* 2de2b0f - Fixed error when checking the pos arg when setting the position - Nicolas Donna
* 34ac7fa - catch error thrown in cross-domain iframe - jiyinyiyong

* 01f1fa1 - add minified file in dist.

### v0.0.6

* 287b5d8 working in iframe

### v0.0.5

* aef0aa4 fix IE input position error
* 4a4f7f7 fix contenteditable null value bug

### v0.0.4

* fix scrolling problem

### v0.0.2

* support `contentEditable` mode
* fix ie bugs, and support IE > 6 to all mode

### 2013-08-07

* fix bug: error position at beginning of textarea
* Bower
* jasmine test

### 2013-03-31

* support IE browsers.
