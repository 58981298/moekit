# 一般使用

---

````javascript
seajs.use('uuid',function(uuid){
    console.log(uuid.v4());
    console.log(uuid.v1());
});
````