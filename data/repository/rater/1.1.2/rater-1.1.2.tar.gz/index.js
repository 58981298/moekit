module.exports = require('./src/rater');

