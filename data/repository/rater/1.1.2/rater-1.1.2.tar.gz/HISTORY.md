# History

---

### 1.1.1
`CHANGED` 完全重构

## 1.1.0
`IMPROVED` 支持`Zepto`

## 1.0.0

`tag:new` seedit/rater 初次提交

