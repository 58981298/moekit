var rater = require('index');
describe('rater', function() {
  it('normal usage', function() {
  });
});

