#!/bin/python

python -m SimpleHTTPServer 8000
