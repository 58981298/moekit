define(function(require) {

  var imageUploader = require('src/uploader');

  describe('imageUploader', function() {

    it('normal usage', function() {

    });
  });

});
