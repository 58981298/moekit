/**
 * 经纬度坐标，优先于自定计算
 */

    module.exports = {
        'Russia': [ 100, 60 ],
        'United States of America': [ -99, 38 ]
    };
;