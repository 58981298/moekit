# History

---

## 0.10.0

`CHANGED` 升级到 spm@3.x

## 0.9.2

`tag:new` 支持 handlebars 的 partial
`tag:improved` renderPartial 没有参数时会整个渲染

## 0.9.1

`tag:fixed` #3 修复 template 编译后 renderPartial 渲染出错的问题

## 0.9.0

`tag:new` 第一个版本，从 widget 迁移出来
