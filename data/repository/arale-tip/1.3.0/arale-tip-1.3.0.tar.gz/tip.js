module.exports = require('./src/tip');
