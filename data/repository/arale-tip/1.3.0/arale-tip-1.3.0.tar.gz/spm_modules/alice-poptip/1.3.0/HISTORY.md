# History

---

## 1.3.0

迁移 spm@3.x

## 1.2.0

`tag:new` 增加 3 6 9 12 四个中点位置的[箭头](/#9%E7%82%B9%E9%92%9F%E4%BD%8D%E7%BD%AE)。

## 1.1.1

`tag:fixed` 解决window下firefox的border渲染出深色边框的[问题](https://i.alipayobjects.com/e/201307/da3fFSyPP.jpg)。

## 1.1.0

`tag:improved` 箭头改用 [border](http://www.css88.com/demo/border/border1.html) 进行实现，使各浏览器效果基本一致。

## 1.0.0

`tag:new` 新组件。

![](https://i.alipayobjects.com/e/201306/VoiDYoRIz.png)

