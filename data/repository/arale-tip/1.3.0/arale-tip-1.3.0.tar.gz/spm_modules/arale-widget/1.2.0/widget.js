module.exports = require('./src/widget')
