# import-style

Embedding style text in JavaScript code

---

## install

```
spm install import-style
```

## Usage [中文文档](https://github.com/seajs/seajs-style/issues/1)

```
require('import-style')('body { margin: 0 }')
```

## LISENCE

Copyright (c) 2014 popomore. Licensed under the MIT license.
