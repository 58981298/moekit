# 历史记录

---

## 1.1.0

`improved` 升级到 spm@3.x 规范。
`fixed` pinElement 不存在时不再报错。https://github.com/aralejs/position/pull/11

## 1.0.1

`tag:fixed` #6 替换 jquery 1.7.2 中的 offset 方法，修复此版本中判断 body 的 offset 位置的问题。

`tag:improved` #5 替换原来用 $.browser 来判断 ie6 的逻辑。


## 1.0.0

`tag:new` 新组件。
