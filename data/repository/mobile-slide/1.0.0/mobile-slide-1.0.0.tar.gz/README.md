# mobile-slide

---

[![spm version](http://spmjs.io/badge/mobile-slide)](http://spmjs.io/package/mobile-slide)

An awesome spm package!

---

## Install

```
$ spm install mobile-slide --save
```

## Usage

```js
var mobile-slide = require('mobile-slide');
// use mobile-slide
```

## Api

Here is more details.

