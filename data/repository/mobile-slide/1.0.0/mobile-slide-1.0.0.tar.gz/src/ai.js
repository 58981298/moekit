var ai = {
    touchClick: function(obj, fun) {
        var start_x = 0,
            start_y = 0;
        obj.addEventListener('touchstart', function(e) {
            start_x = e.touches[0].clientX;
            start_y = e.touches[0].clientY;
            document.addEventListener('touchend', touEnd, false);
        });

        function touEnd(e) {
            var endX = e.changedTouches[0].clientX;
            var endY = e.changedTouches[0].clientY;
            if (Math.abs(endX - start_x) < 5 && Math.abs(endY - start_y) < 5) {
                fun.call(obj, e);
            }
            document.removeEventListener('touchend', touEnd, false);
        };
    },
    ovb: {
        _version_value: false,
        _bversion_value: false,
        _ua: navigator.userAgent,
        android: function() {
            var regular_result = this._ua.match(/(Android)\s+([\d.]+)/),
                os_boolean = !! regular_result;
            if (!this._version_value && os_boolean) {
                this._version_value = regular_result[2];
            }
            this.android = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        ios: function() {
            var regular_result = this._ua.match(/.*OS\s([\d_]+)/),
                os_boolean = !! regular_result;
            if (!this._version_value && os_boolean) {
                this._version_value = regular_result[1].replace(/_/g, '.');
            }
            this.ios = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        ipod: function() {
            var regular_result = this._ua.match(/(iPod).*OS\s([\d_]+)/),
                os_boolean = !! regular_result;
            if (!this._version_value && os_boolean) {
                this._version_value = regular_result[2].replace(/_/g, '.');
            }
            this.ipod = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        ipad: function() {
            var regular_result = this._ua.match(/(iPad).*OS\s([\d_]+)/),
                os_boolean = !! regular_result;
            if (!this._version_value && os_boolean) {
                this._version_value = regular_result[2].replace(/_/g, '.');
            }
            this.ipad = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        iphone: function() {
            var regular_result = this._ua.match(/(iPhone);.*OS\s([\d_]+)/),
                os_boolean = !! regular_result;
            if (!this._version_value && os_boolean) {
                this._version_value = regular_result[2].replace(/_/g, '.');
            }
            this.iphone = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        kindle: function() {
            var regular_result = this._ua.match(/Kindle\/([\d.]+)/),
                os_boolean = !! regular_result;
            if (!this._version_value && os_boolean) {
                this._version_value = regular_result[1];
            }
            this.kindle = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        webkit: function() {
            var regular_result = this._ua.match(/WebKit\/([\d.]+)/),
                os_boolean = !! regular_result;
            if (!this._version_value && os_boolean) {
                this._bversion_value = regular_result[1];
            }
            this.webkit = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        uc: function() {
            var regular_result = this._ua.match(/UC/),
                os_boolean = !! regular_result;
            this.uc = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        opera: function() {
            var regular_result = this._ua.match(/Opera/),
                os_boolean = !! regular_result;
            this.opera = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        safari: function() {
            var regular_result = this._ua.match(/Version.*Safari/),
                os_boolean = !! regular_result;
            this.safari = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        silk: function() {
            var regular_result = this._ua.match(/Silk/),
                os_boolean = !! regular_result;
            this.silk = function() {
                return os_boolean;
            };
            return os_boolean;
        },
        version: function() {
            return this._version_value;
        },
        bVersion: function() {
            return this._bversion_value;
        }
    },
    a: function(s) {
        return document.querySelectorAll(s);
    },
    q: function(s) {
        return document.querySelector(s);
    },
    i: function(id) {
        return document.getElementById(id);
    },
    c: function(klass) {
        return document.getElementsByClassName(klass);
    },
    hideUrl: function() {

        setTimeout(function() {
                window.scrollTo(0, 1);

            },
            200)
    },
    wh: function() {
        return document.documentElement.clientHeight;
    },
    ww: function() {
        return document.documentElement.clientWidth;
    },
    hv: function() {
        if (this.wh() / this.ww() > 1) {
            return true;
        } else {
            return false;
        }
    },
    resize: function(fun) {

        this.resize_time = Date.now();
        window.addEventListener('resize', function() {
            if (Date.now() - this.resize_time < 200) {
                this.resize_time = Date.now();
            } else {
                fun();
                this.resize_time = Date.now();
            }
        }, false);

    },
    clone: function(object) {
        function f() {}
        f.prototype = object;
        return new f;
    },
    extend: function(subClass, superClass) {
        var f = function() {};
        f.prototype = superClass.prototype;
        subClass.prototype = new f();
        subClass.prototype.constructor = subClass;
        subClass.superclass = superClass.prototype;
        if (superClass.prototype.constructor == Object.prototype.constructor) {
            superClass.prototype.constructor = superClass;
        }
    },
    styleLoad: function(url, fun) {
        var A = document.createElement("style");
        A.type = "text/css";
        A.src = url;
        document.head.appendChild(A)
        A.onload = function() {
            fun()
        };
    },
    scriptLoad: function(url, fun) {
        var A = document.createElement("script");
        A.type = "text/javascript";
        A.src = url;
        document.head.appendChild(A);
        A.onload = function() {
            fun()
        };
    },
    touchMovePreventDefault: function(obj) {
        obj.addEventListener("touchmove", function(e) {
            e.preventDefault();
        }, false);
    },
    touchStartEvent: function(dom, func) {
        var supportsTouches = ("createTouch" in document);
        if (supportsTouches) {
            dom.addEventListener('touchstart', func, false);
        } else {
            dom.addEventListener('click', func, false);
        }
    },
    removeTouchStartEvent: function(dom, func) {
        var supportsTouches = ("createTouch" in document);
        if (supportsTouches) {
            dom.removeEventListener('touchstart', func, false);
        } else {
            dom.removeEventListener('click', func, false);
        }
    }
};

module.exports = ai;