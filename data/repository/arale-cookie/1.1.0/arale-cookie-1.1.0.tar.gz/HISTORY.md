# History

---

## 1.1.0

`improved` 按照 spm@3.x 规范升级。

