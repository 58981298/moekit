# Pager

---

### jQuery pagination plugin (bootstrap powered)

[Documentation](http://esimakin.github.io/twbs-pagination/)

### Changelog
v1.2
- 可配置分页容器的类名和分页按钮的类名

v1.1
- Added 'hold current page on center'

v1.0
- Simple pagination

### reference

+ http://jplist.com/