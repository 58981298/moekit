# Pager

---

### jQuery pagination plugin (bootstrap powered)

[Documentation](http://esimakin.github.io/twbs-pagination/)

### Changelog

v1.1
- Added 'hold current page on center'

v1.0
- Simple pagination