var seeditHelper;
var BBS = require('seedit-bbs');
var Url = require('url');
var Base64 = {
	_keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
	encode: function(e) {
		var t = "";
		var n, r, i, s, o, u, a;
		var f = 0;
		e = Base64._utf8_encode(e);
		while (f < e.length) {
			n = e.charCodeAt(f++);
			r = e.charCodeAt(f++);
			i = e.charCodeAt(f++);
			s = n >> 2;
			o = (n & 3) << 4 | r >> 4;
			u = (r & 15) << 2 | i >> 6;
			a = i & 63;
			if (isNaN(r)) {
				u = a = 64
			} else if (isNaN(i)) {
				a = 64
			}
			t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
		}
		return t
	},
	_utf8_encode: function(e) {
		e = e.replace(/\r\n/g, "\n");
		var t = "";
		for (var n = 0; n < e.length; n++) {
			var r = e.charCodeAt(n);
			t += String.fromCharCode(r)
		}
		return t
	}
}

// new http://bbs.bozhong.com/qa/9?x-block=shouye
// old http://huodong.bozhong.com/restful/qazhuanti/item.html?id=2

function shortQA(link) {
	var url = new Url(link);
	var path = url.path;
	if (/restful/.test(url)) {
		return 'qa_' + url.getParam('id');
	} else {
		return 'qa_' + path.replace('/qa/', '');
	}
};

// new  http://huodong.bozhong.com/zhuanjia/10
// old  http://huodong.bozhong.com/zhuanjia/index.html?id=3&x-page=www
// list http://huodong.bozhong.com/zhuanjia/
function shortZhuanjia(link) {
	var url = new Url(link);
	if (/index.html/.test(link)) { // old
		return 'zj_' + url.getParam('id');
	} else {
		var id = url.path.replace('/zhuanjia/', '');
		if (id) {
			return 'zj_' + id;
		} else {
			return 'zj_list';
		}
	}
}

// get base64
function other(link) {
	return 'link_' + Base64.encode(link).slice(-10);
};


function convert(url) {
	if (BBS.page.isTopic(url)) {
		return 'tid_' + BBS.page.getTid(url);
	} else if (BBS.page.isNode(url)) {
		return 'fid_' + BBS.page.getFid(url);
	} else if (/qa\/\d+/.test(url)) {
		return shortQA(url);
	} else if (/\/zhuanjia/.test(url)) {
		return shortZhuanjia(url);
	} else if (/qazhuanti/.test(url)) {
		return shortQA(url);
	} else {
		return other(url);
	}
};

exports.getShortId = convert;