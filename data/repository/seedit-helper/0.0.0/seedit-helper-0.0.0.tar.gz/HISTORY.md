# History

---

## 0.0.0

`new` It is the first version of seedit-helper.
