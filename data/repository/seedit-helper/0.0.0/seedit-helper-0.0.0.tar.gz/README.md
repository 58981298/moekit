# seedit-helper [![spm version](https://moekit.timo.today/badge/seedit-helper)](https://moekit.timo.today/package/seedit-helper)

---
公用方法



## Usage

```js
var seeditHelper = require('seedit-helper');
// use seeditHelper
```

## API

### getShortId(url)

转换链接为短链接，方便统计。可能有遗漏，后面逐渐添加完整。

规则如下：

+ 帖子链接       => 'tid_1254'
+ 版块链接       => 'fid_24',
+ QA专题         => 'qa_10',
+ 专家问答       => 'zj_9',
+ 专家问答列表页 => 'zj_list'
+ 其他链接       => 'link_base64的后面10个字符'
