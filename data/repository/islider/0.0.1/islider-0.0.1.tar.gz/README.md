# islider [![spm version](https://moekit.timo.today/badge/islider)](https://moekit.timo.today/package/islider)

---



## Install

```
$ spm install islider --save
```

## Usage

```js
var islider = require('islider');
// use islider
```
