# History

---

## 1.1.0

`improved` 升级到 spm@3.x 规范。
