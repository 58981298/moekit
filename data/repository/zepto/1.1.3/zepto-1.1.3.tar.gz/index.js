require('./src/zepto');
require('./src/event');
require('./src/ajax');
require('./src/form');
require('./src/ie');
module.exports = window.Zepto;