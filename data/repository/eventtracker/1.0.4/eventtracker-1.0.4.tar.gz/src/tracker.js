window.jQuery = window.jQuery || require('jquery');
var analytics = {};
// define global variable `_gaq` used by GA
window._gaq = window._gaq || [];
// trackable tags
var tags = ['a', 'span', 'button', 'input', 'label', 'img'];
var eventNamespace = '.data-track';
var mainEvent = 'click';
var log = false;
(function($) {
    var $doc = $(document),
        // service
        service = {
            googleAnalytics: function(key) {
                var _key = key.split('/');
                // if `event tag` not defined
                if (_key[2] === undefined) {
                    _key[2] = '';
                }
                _gaq.push(['_setAccount', this.UA]);
                _gaq.push(['_trackEvent', _key[0], _key[1], _key[2]]);
            }
        },
        // predefined params
        preParams = {};

    // manually bind delegate event
    var _bindDelegateEvent = function(el, key) {
        $doc.on(mainEvent + eventNamespace, el, function() {
            analytics.doTrack(key);
        });
    };

    analytics = {
        init: function(options) {
            var _this = this;
            // main event
            if (options.mainEvent) {
                mainEvent = options.mainEvent;
            }
            // do log?
            if (options.log === true) {
                log = true;
            }
            // trackable tags
            tags = options.tags || tags;
            // convert to tag[data-track] for performance improvement
            var iTags = $.map(tags, function(one) {
                return one + '[data-track]';
            }).join(',');
            // ua
            if (options.UA) {
                this.UA = options.UA;
            } else {
                throw 'no UA value specified';
            }
            // pre defined value
            preParams = options.preParams || {};

            // walk and parse links
            analytics.walkTrack();
            // add delegate listener for links, button, span, and input
            $doc.on(mainEvent + eventNamespace, iTags, trackHandler);

            // data-track-on
            var trackOnTags = $.map(tags, function(one) {
                return one + '[data-track-on]';
            }).join(',');

            var $trackOnElements = $(trackOnTags);
            $trackOnElements.each(function(index, one) {
                var event = $(one).attr('data-track-on');
                $(one).on(event, function() {
                    // execute service function
                    $.each(service, function(index, _one) {
                        _one.call(_this, $(one).attr('data-track'));
                    });
                });
            });

            // normal tracker

            function trackHandler(e) {
                var $this = $(this),
                    key = $this.attr('data-track');
                if (key && !$this.attr('data-track-on')) {
                    if (key.indexOf('{') !== -1) {
                        key = _this.parseTrack(key);
                    }
                    if (log) {
                        window.console && console.log(key);
                    }
                    // execute service function
                    $.each(service, function(index, one) {
                        one.call(_this, key);
                    });
                }
            };
        },

        // set pre params
        setPreParams: function(params) {
            if ($.isPlainObject(params)) {
                for (var p in params) {
                    preParams[p] = params[p];
                }
            }
            this.walkTrack();
        },

        // get pre params
        getPreParam: function(k) {
            return preParams[k];
        },

        // add analytics service
        addService: function(name, trackFunction) {
            service[name] = trackFunction;
        },

        // remove service
        removeService: function(name) {
            delete service[name];
        },

        // list service
        listService: function() {
            return service;
        },

        // add track data for tags
        addTrack: function(selector, track) {
            var _this = this,
                _addTrack = function(selector, track) {
                    $(selector).attr('data-track', track);
                    _this.walkTrack($(selector));
                },
                type = $.type(selector);
            // single argument
            if (type === 'string') {
                if ($(selector).length === 0) {
                    _bindDelegateEvent(selector, track);
                    return;
                }
                _addTrack(selector, track);
            } else if (type === 'object') { // batch add
                for (var el in selector) {
                    // el not exists in dom
                    if ($(el).length === 0) {
                        _bindDelegateEvent(el, selector[el]);
                        return;
                    }
                    _addTrack(el, selector[el]);
                }
            }
        },

        // parse single track key
        parseTrack: function(key) {
            var _this = this;
            key = key.replace(/(\{\w+\})/g, function(word) {
                var mapName = word.slice(1, -1);
                if (preParams[mapName] !== undefined) {
                    return preParams[mapName];
                }
                return word;
            });
            return key;
        },
        // parse single link
        walkSingleLink: function($one) {
            var _this = this,
                // collect the link's attributes
                config = {
                    key: $one.attr('data-track'),
                    txt: $one.text(),
                    title: $one.attr('title'),
                    alt: $one.attr('alt')
                };
            // mix into `trackMap`
            $.each(['txt', 'alt', 'title'], function(key, val) {
                preParams[val] = $.trim(config[val]);
            });
            // set a new attribute value for `data-track`
            $one.attr('data-track', _this.parseTrack(config.key));
            // clean unused `preParams` properties
            $.each(['txt', 'alt', 'title'], function(key, val) {
                delete(preParams[val]);
            });
        },
        // walk the links
        walkTrack: function(parent) {
            parent = parent || document;
            var $links = !! $(parent).attr('data-track') ? $(parent) : $(parent).find("[data-track]");
            $links.each(function(index, item) {
                var $one = $(item);
                if ($.inArray(item.nodeName.toLowerCase(), tags) !== -1) {
                    analytics.walkSingleLink($one);
                } else {
                    var $olinks = $one.find(tags.join(',')),
                        multiKey = $one.attr('data-track');
                    $olinks.each(function(index, citem) {
                        var $citem = $(citem);
                        $citem.attr('data-track', multiKey);
                        analytics.walkSingleLink($citem);
                    });
                }
            });
        },
        // do track !
        doTrack: function(key) {
            if (!key) {
                return;
            }
            // execute track function
            if ($.isPlainObject(service)) {
                for (var s in service) {
                    service[s].call(this, key);
                }
            }
        }
    };

})(window.jQuery || window.Zepto);
module.exports = analytics;