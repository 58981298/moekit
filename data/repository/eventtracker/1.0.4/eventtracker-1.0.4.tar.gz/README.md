# Event Tracker [![Build Status](https://travis-ci.org/airyland/eventTracker.png?branch=master)](https://travis-ci.org/airyland/seedit.GA-event-tracker)  [![Coverage Status](https://coveralls.io/repos/airyland/eventTracker/badge.png)](https://coveralls.io/r/airyland/eventTracker)

---
更加方便地添加网站事件统计

该脚本是PC站统计的根基，提供了用`data-track`快速添加统计的使用方法。

`WAP`站的用户行为统计从`V2`开始进行。

---

## 使用说明


### init <em>function(option)</em>
入口方法，加载时需要执行该方法进行初始化

参数说明：

+ `UA`   google统计id，必须
+ `tags` 进行统计的html标签数组，不指定的将不会统计点击事件。

    默认值为 `['a', 'span', 'button', 'input', 'label', 'img']`

+ `log` 是否在控制台输出log
+ `mainEvent` 关键事件，默认为`click`,如果是手机站，可以设定为 `tap`
+ `preParams` 统计变量对象，支持多个，在data-track中包含在花括号中。

   如在data-track中使用 {domain}，对应的preParams应该设定为
  `{domain:'想要设定的值 '}`
 ---
  **注意**:`{alt}`,`{txt}`,`{title}`为关键词，会自动从当前链接中动态取值，不可用preParams进行设置。

 ---


### doTrack <em>function(trackkey)</em>

发送统计请求，一般用于在JS中进行手动统计。

```javascript
doTrack('bbs/首页/点击发帖');
```

### addTrack <em>function(selector,trackkey)</em>
JS方式添加统计项，支持批量添加

单个统计添加

```javascript
addTrack('a.hello','事件分类/事件行为/事件标签')
```

批量添加

```javascript
addTrack({
  'a.hello1':'事件分类1/事件行为1/事件标签1',
  'b.hello2':'事件分类2/事件行为2/事件标签2'
});
```


### addService <em>function(name,trackFunction)</em>
添加统计服务，参数为变量(如果有的话)解析后的统计字符

默认会建立名为`ga`的服务，添加同名会覆盖原来的服务。



```javascript
addService('baidu',function(key){
   // may be baidu.track(key);
});
```

### removeService <em>function(name)</em>
移除统计服务

### listService  <em>function</em>
列出当前所有统计服务




