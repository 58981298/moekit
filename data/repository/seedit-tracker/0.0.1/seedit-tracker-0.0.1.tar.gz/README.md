# seedit-tracker [![spm version](https://moekit.timo.today/badge/seedit-tracker)](https://moekit.timo.today/package/seedit-tracker)

---



## 使用

该模块用于简化页面百度(谷歌)统计代码的添加。


## Usage

```js
var Tracker = require('seedit-tracker');
// 加载一个百度统计
Tracker.baidu.add('86b18e74389b9186f2583902edce4ed9');
```
