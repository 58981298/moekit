# History

---

## 1.2.0

`improved` 升级到 spm@3.x 规范。

## 1.1.2

`tag:fixed` 修复 `trigger('all')` 的时候触发两次的问题 

## 1.1.1

`tag:fixed` #8 修复 mixTo 方法处理模拟 prototype 出错的问题

`tag:improved` 优化 triggerEvents

`tag:new` #9 增加 emit 接口，等同于 trigger

`tag:new` #6 增加 once 接口

## 1.1.0

`tag:changed` [#5](https://github.com/aralejs/events/issues/5) trigger 返回值变化。

## 1.0.0

正式版
