# Histroy

---

## 1.1.0

`improved` 升级到 spm@3.x 规范。


## 1.0.2

`tag:fixed` [#3](https://github.com/aralejs/iframe-shim/issues/3) 修复除 ie6 下，sync 链式调用的问题

`tag:improved` 去除 $.browser 的依赖

`tag:improved` 升级 position 到 1.0.1

## 1.0.1

`tag:fixed` [#2](https://github.com/aralejs/iframe-shim/issues/2) 修复被遮挡元素设置了z-index导致的问题

## 1.0.0

发布稳定版本

## 0.9.3

`tag:fixed` 修复 `src="javascript:;"` 时的安全警报

## 0.9.2

发布第一个版本
