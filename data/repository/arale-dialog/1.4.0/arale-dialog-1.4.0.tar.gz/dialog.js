module.exports = require('./src/dialog');
module.exports.ConfirmBox = require('./src/confirmbox');
