module.exports = require('./src/popup');
