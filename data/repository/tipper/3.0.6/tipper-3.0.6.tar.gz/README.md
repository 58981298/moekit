# Tipper
---
<a href="http://gruntjs.com" target="_blank"><img src="https://cdn.gruntjs.com/builtwith.png" alt="Built with Grunt"></a>

A jQuery plugin for simple tooltips. Part of the formstone library. 

- [Demo](http://formstone.it/components/Tipper/demo/index.html) 
- [Documentation](http://formstone.it/tipper/) 

#### Bower Support 
`bower install Tipper`