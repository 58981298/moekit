# dialog

---

[![Build Status](https://secure.travis-ci.org/airyland/seedit.ui.dialog.png)](https://travis-ci.org/airyland/seedit.ui.dialog)
[![Coverage Status](https://coveralls.io/repos/airyland/seedit.ui.dialog/badge.png?branch=master)](https://coveralls.io/r/airyland/seedit.ui.dialog)


Dialog solution

---

## 使用说明


## API
