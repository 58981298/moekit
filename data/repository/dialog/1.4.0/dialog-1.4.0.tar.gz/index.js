module.exports = require('arale-dialog');

