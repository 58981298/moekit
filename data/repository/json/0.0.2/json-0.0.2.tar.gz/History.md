
0.0.2 / 2013-05-28 
==================

  * require component-json-fallback
