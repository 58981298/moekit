# 演示文档

---

````javascript
seajs.use('../url', function(url){

});
````
