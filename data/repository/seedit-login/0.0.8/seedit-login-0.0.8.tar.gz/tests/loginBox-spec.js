define(function(require) {

  var loginBox = require('index');

  describe('loginBox', function() {

    it('normal usage', function() {

    });
  });

});
