# History

---

## 0.0.8

`IMPROVED`  按钮选择器不使用id

## 0.0.7

`CHANGED` 彻底重构，更换dialog组件，更换API组件

`IMPROVED` 增加`title`选项 0828 玉燕斯利安备孕小手册下载时需要登录框提示

`UNRESOLVED` 同一trigger只创建一个实例，不能重复创建

`UNRESOLVED` 按钮选择器不使用id

## 0.0.3

`CHANGED` dialog 依赖更新到`0.0.2`

## 0.0.1

`tag:new` seedit/loginBox 初次提交

