# History

---

## 0.0.7

`CHANGED` 彻底重构，更换dialog组件，更换API组件

## 0.0.3

`CHANGED` dialog 依赖更新到`0.0.2`

## 0.0.1

`tag:new` seedit/loginBox 初次提交

