define(function(require) {

  var loginBox = require('loginBox');

  describe('loginBox', function() {

    it('normal usage', function() {

    });
  });

});
