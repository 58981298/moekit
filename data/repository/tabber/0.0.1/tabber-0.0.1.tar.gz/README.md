# tabber

---

[![spm version](http://spmjs.io/badge/tabber)](http://spmjs.io/package/tabber)

An awesome spm package!

---

## Install

```
$ spm install tabber --save
```

## Usage

```js
var tabber = require('tabber');
// use tabber
```

## Api

Here is more details.

