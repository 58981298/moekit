# History

---

## 0.0.2
`NEW` 增加`login`,`logout`函数

`NEW` 引入事件机制

`NEW` 保存用户最近登录信息，方便下次登录时不需要填用户名

## 0.0.1

`tag:new` moe/seedit.user 初次提交

