
1.0.0 / 2014-04-24 
==================

 * add tests
 * make sure exposed `JSON` doesn't override / depend on `window.JSON` because mootools, breaks `window.JSON`.
 * fix install name [gjohnson]
