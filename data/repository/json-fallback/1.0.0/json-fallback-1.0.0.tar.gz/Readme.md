
# json-fallback

  JSON parser / stringifier fallback for [json](https://github.com/component/json).

## Installation

    $ component install component/json-fallback

# License

  MIT


