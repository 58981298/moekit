# dialoger

---

[![spm version](http://spmjs.io/badge/dialoger)](http://spmjs.io/package/dialoger)

An awesome spm package!

---

## Install

```
$ spm install dialoger --save
```

## Usage

```js
var dialoger = require('dialoger');
// use dialoger
```

## Api

Here is more details.

