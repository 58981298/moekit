module.exports = {
  'Su': 'S',
  'Mo': 'M',
  'Tu': 'T',
  'We': 'W',
  'Th': 'T',
  'Fr': 'F',
  'Sa': 'S',
  'Jan': 'Jan',
  'Feb': 'Feb',
  'Mar': 'Mar',
  'Apr': 'Apr',
  'May': 'May',
  'Jun': 'Jun',
  'Jul': 'Jul',
  'Aug': 'Aug',
  'Sep': 'Sep',
  'Oct': 'Oct',
  'Nov': 'Nov',
  'Dec': 'Dec'
};

