# test
---

````iframe:600
<div id="demo" style="width:100%;height:600px;"></div>
<script>
seajs.use('./demo.js');
</script>
````

