# History

---

## 0.0.2

`CHANGED` 迁移到`spm@3.x`
`IMPROVED` 忽略 `#` 和 `javascript:` 链接

## 0.0.1

`tag:new` seedit-from 初次提交

