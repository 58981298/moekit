# jsonp [![spm version](http://spmjs.io/badge/jsonp)](http://spmjs.io/package/jsonp)

---

An awesome spm package!

---

## Install

```
$ spm install jsonp --save
```

## Usage

```js
var jsonp = require('jsonp');
// use jsonp
```
