var jQuery = require('jquery');
var $ = require('index')(jQuery);

describe('iframeAjax', function () {

    it('normal usage', function () {
        $('<a href="javascript:" id="test">start</a>').appendTo('body');
        $('#test').click(function (e) {
            e.preventDefault();
            var xhr = $.ajax({
                url: 'http://common.seedit.com/ucenter/login.iframe',
                iframe: true,
                dataType: "text",
                type: 'POST',
                data: {
                    username: 'airyland',
                    password: 'test'
                },
                success: function (data) {
                    alert(data);
                },
                complete: function (xhr, statusText) {

                },
                error: function () {

                }
            });
        });
        $('#test').trigger('click');
    });
});