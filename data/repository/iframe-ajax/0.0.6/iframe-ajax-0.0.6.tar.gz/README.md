# iframeAjax

---

[![Build Status](https://secure.travis-ci.org/airyland/seedit.iframeAjax.png)](https://travis-ci.org/airyland/seedit.iframeAjax)
[![Coverage Status](https://coveralls.io/repos/airyland/seedit.iframeAjax/badge.png?branch=master)](https://coveralls.io/r/airyland/iframeAjax)


IE(6)跨域坑爹。因此通过为`jQuery.ajax`添加一个`iframe` `transport` 来实现`伪Ajax`请求。

`注意:`这里的跨域是指`子域之间`和`主域与子域`之间的跨域。

---



## 使用说明
和正常使用`$.ajax`一样，但是需要在`option`上加上`iframe:true`

```javascript
seajs.use('iframeAjax',function($){
    $.ajax({
        url: 'http://dev03.seedit.com/api.html',
        iframe: true,
        dataType: "json",
        success: function(data) {
            alert(data);
        }
    });
});

```


## 服务端返回说明
1.需要将内容包含于`textarea`标签中。

2.如果为跨子域，那么需要在设定`document.domain`为主域名。

```javascript
<script>document.domain = 'seedit.com';</script>
<textarea>{"hello":"world"}</textarea>
```


## todo

+ 支持文件上传
+ 支持直接从form表单提交，而不是现在的根据`data`建一个隐藏表单再提交。