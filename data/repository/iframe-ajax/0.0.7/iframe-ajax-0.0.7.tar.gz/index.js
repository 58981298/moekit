module.exports = require('./src/iframeAjax.js');
