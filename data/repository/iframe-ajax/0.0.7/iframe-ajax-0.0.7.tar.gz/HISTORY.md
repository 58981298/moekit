# History

---

## 0.0.1

`tag:new` seedit/iframeAjax 初次提交

## 0.0.2
`CHANGED` 更改命名空间为 `moe`

## 0.0.6
稳定版本

## 0.0.7
`CHANGE`  增加`form`参数，支持从表单直接提交
