# 演示文档

---


<form action="http://127.0.0.1:8005" method="GET">
    <input type="submit" value="提交" id="submit">
</form>

<form action="http://127.0.0.1:8005" method="POST" id="form2">
	<input name="key" value="value">
    <input type="submit" value="提交" id="submit2">
</form>

````javascript
seajs.use(['jquery','index'],function($,iframeAjax){
	iframeAjax($);
	$('#submit').click(function(e){
        e.preventDefault();
        $.ajax({
        type:'get',
        url:'/examples/api.html',
        iframe:true,
		success:function(data){
			console.log(data,$.parseJSON(data));
			
		}
        });
    });
	
	$('#submit2').click(function(e){
        e.preventDefault();
        $.ajax({
        type:'get',
        url:'/examples/api.html',
        iframe:true,
		form:'#form2',
		success:function(data){
			console.log(data,$.parseJSON(data));
			
		}
        });
    });
	
});
````
