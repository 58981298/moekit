# History

---

## 1.0.2

`CHANGED` 迁移到 `spm@3.x`

## 1.0.1

`CHANGED` 废弃 `user`对象，`isLogin`函数由 `seedit.user`模块支持

`fixed`   WAP站帖子页面不输出 `fid`，因此暂时改为从DOM中获取fid


## 1.0.0

`tag:new` moe/seedit.bbs 初次提交


