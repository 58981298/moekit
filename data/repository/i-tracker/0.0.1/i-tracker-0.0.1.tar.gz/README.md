# i-tracker

---

[![spm version](http://spmjs.io/badge/i-tracker)](http://spmjs.io/package/i-tracker)

An awesome spm package!

---

## Install

```
$ spm install i-tracker --save
```

## Usage

```js
var iTracker = require('i-tracker');
// use iTracker
```

## Api

Here is more details.

