
$.fullCalendar.lang("is", {
	defaultButtonText: {
		month: "Mánuður",
		week: "Vika",
		day: "Dagur",
		list: "Dagskrá"
	},
	allDayText: "Allan daginn"
});
