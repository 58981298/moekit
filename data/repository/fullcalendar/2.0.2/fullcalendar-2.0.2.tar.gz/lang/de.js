
$.fullCalendar.lang("de", {
	defaultButtonText: {
		month: "Monat",
		week: "Woche",
		day: "Tag",
		list: "Terminübersicht"
	},
	allDayText: "Ganztägig"
});
