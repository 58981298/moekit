
$.fullCalendar.lang("fr", {
	defaultButtonText: {
		month: "Mois",
		week: "Semaine",
		day: "Jour",
		list: "Mon planning"
	},
	allDayHTML: "Toute&nbsp;la journée" // allDayHTML is discouraged but used here as a hack to get the breaking correct
});
