
$.fullCalendar.lang("hu", {
	defaultButtonText: {
		month: "Hónap",
		week: "Hét",
		day: "Nap",
		list: "Napló"
	},
	allDayText: "Egész nap"
});
