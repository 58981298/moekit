
$.fullCalendar.lang("pl", {
	defaultButtonText: {
		month: "Miesiąc",
		week: "Tydzień",
		day: "Dzień",
		list: "Plan dnia"
	},
	allDayText: "Cały dzień"
});
