
$.fullCalendar.lang("el", {
	defaultButtonText: {
		month: "Μήνας",
		week: "Εβδομάδα",
		day: "Ημέρα",
		list: "Ατζέντα"
	},
	allDayText: "Ολοήμερο"
});
