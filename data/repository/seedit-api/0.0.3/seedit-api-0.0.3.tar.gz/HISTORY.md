# History

---

## 0.0.1

`tag:new` seedit/API 初次提交

## 0.0.2
`CHANGED` 命名空间更改为 `moe`

## 0.0.3
`FIXED` 修复 API 指定测试域名 'http://mecommon.seedit.dev/' 报错的情况

