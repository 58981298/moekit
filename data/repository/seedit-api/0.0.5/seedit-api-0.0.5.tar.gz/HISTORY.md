# History

---

## 0.0.5

`CHANGED` 大重构，支持事件监听，太花时间了。。

`IMPROVED` 支持相对路径的`scope`参数

## 0.0.4

`IMPROVED` 从 `seedit-config` 模块中获取API配置

## 0.0.2
`CHANGED` 命名空间更改为 `moe`


## 0.0.3
`FIXED` 修复 API 指定测试域名 'http://mecommon.seedit.dev/' 报错的情况

## 0.0.1

`tag:new` seedit/API 初次提交




