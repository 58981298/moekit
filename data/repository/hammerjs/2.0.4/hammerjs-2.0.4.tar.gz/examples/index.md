# test
---

````javascript
seajs.use('hammer',function(Hammer){
	console.log(Hammer);
});
````