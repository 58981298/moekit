# 依赖 Zepto

---

````html
<script src="http://scdn.bozhong.com/source/common/js/zepto.min.js"></script>
<ul data-track="hello/world/{txt}">
    <li><a href="javascript:">test001</a></li>
    <li><a href="javascript:">test002</a></li>
</ul>
````

````javascript
delete window.jQuery;
seajs.use('index', function(tracker){
    console.log(tracker);
    tracker.init({UA:'12345678'});
});
````
