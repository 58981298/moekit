# 依赖jQuery

---

````html
<ul data-track="hello/world/{txt}">
    <li><a href="javascript:">test001</a></li>
    <li><a href="javascript:">test002</a></li>
</ul>
````

````javascript
seajs.use('index', function(tracker){
    console.log(tracker);
    tracker.init({UA:'12345678',log:true});
});
````
