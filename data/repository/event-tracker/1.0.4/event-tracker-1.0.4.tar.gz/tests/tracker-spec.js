var tracker = require('index');
var expect = require('expect');
var $ = require('jquery');

/**
beforeEach(function() {
    tracker.init({
        UA: '12345678'
    });
});
**/

var simpleRun = function() {
    tracker.init({
        UA: '12345678'
    });
};

afterEach(function() {
    $('body').find('a,img,#target,span').remove();
    $(document).off('.data-track');
    var services = tracker.listService();
    for (var i in services) {
        if (i !== 'googleAnalytics')
            delete services[i];
    }
});

describe('单个链接自动解析', function() {
    it('txt值 带一个参数单个链接解析', function() {
        $('<a href="#" data-track="a/b/{txt}" id="target">haha</a>').appendTo('body');
        simpleRun();
        expect($('#target').data('track')).to.be('a/b/haha');
    });

    it('带两个参数单个链接解析', function() {
        $('<a href="#" data-track="a/{txt}/{txt}" id="target">haha</a>').appendTo('body');
        simpleRun();
        expect($('#target').data('track')).to.be('a/haha/haha');
    });

    it('带两个参数加其他字符单个链接解析', function() {
        $('<a href="#" data-track="a/{txt}/a-{txt}" id="target">haha</a>').appendTo('body');
        simpleRun();
        expect($('#target').data('track')).to.be('a/haha/a-haha');
    });

    it('title值', function() {
        $('<a href="#" data-track="a/b/{title}" id="target" title="nana">haha</a>').appendTo('body');
        simpleRun();
        expect($('#target').data('track')).to.be('a/b/nana');
    });

    it('alt值', function() {
        $('<img src="" data-track="a/b/{alt}"  alt="xaxa" id="target">').appendTo('body');
        simpleRun();
        expect($('#target').data('track')).to.be('a/b/xaxa');
    });

    it('没有定义的变量值', function() {
        $('<a href="#" data-track="a/b/{other}" id="target">test</a>').appendTo('body');
        simpleRun();
        expect($('#target').data('track')).to.be('a/b/{other}');
    });

});

describe('整块解析', function() {
    it('整块不带参数', function() {
        $('<div id="target" data-track="a/b/c"><a href="">test</a><img src="" alt=""><span>test</span></div>').appendTo('body');
        simpleRun();
        expect($('#target>a').data('track')).to.be('a/b/c');
        expect($('#target>img').data('track')).to.be('a/b/c');
        expect($('#target>span').data('track')).to.be('a/b/c');
    });
});

describe('服务测试', function() {
    it('listService', function() {
        expect(Object.keys(tracker.listService()).length).to.be(1);
    });

    it('removeService', function() {
        tracker.addService('hello', function() {});
        expect(Object.keys(tracker.listService()).length).to.be(2, '返回两个');
        tracker.removeService('hello');
        expect(Object.keys(tracker.listService()).length).to.be(1, '返回剩下的一个');
        expect(typeof tracker.listService()['googleAnalytics']).to.be('function', '移除正确');
    });
});

describe('点击事件', function() {

    it('添加一个处理事件', function() {
        $('<a href="#" data-track="a_b_c" id="tag07">test</a>').appendTo('body');
        simpleRun();
        tracker.addService('googleAnalytics', function() {});
        tracker.addService('test1', function(key) {
            $('body').append('<span id="' + key + '">I am generated.</span>')
        });
        $('#tag07').trigger('click');
        expect($('#' + 'a_b_c').length).to.be(1, '返回1');
        $('#a_b_c').remove();
    });

    it('添加两个处理事件', function() {
        $('<a href="#" data-track="a_b_c" id="tag07">test</a>').appendTo('body');
        simpleRun();
        tracker.addService('test2', function(key) {
            $('body').append('<span id="' + key + '_01">I am generated.</span>')
        });
        $('#tag07').trigger('click');
        expect($('#' + 'a_b_c_01').length).to.be(1, '返回1')
    });
});

describe('addTrack', function() {
    it('加载时不存在dom中的统计', function() {
        tracker.addTrack({
            '#notexist': 'aa_bb_cc'
        });
        tracker.addService('test3', function(key) {
            $('body').append('<span id="' + key + '_00">I am generated.</span>');
        });
        $('<a href="#" id="notexist">nani</a>').appendTo('body');
        $('#notexist').trigger('click');
        expect($('#aa_bb_cc_00').length).to.be(1, '点击触发');
        tracker.removeService('test3');
    });

    it('string arguments with existed element', function() {
        $('<a href="#" id="target">exists</a>').appendTo('body');
        tracker.addTrack('#target', 'hahaha/nanana');
        expect($('#target').data('track')).to.be('hahaha/nanana', 'should return the track keys');
    });

    it('object arguments with existed element', function() {
        $('<a href="#" id="target01">exists01</a><a href="#" id="target02">exists02</a>').appendTo('body');
        tracker.addTrack('a', 'aaa/bbb/{txt}');
        expect($('#target01').data('track')).to.be('aaa/bbb/exists01');
        expect($('#target02').data('track')).to.be('aaa/bbb/exists02');
    });
});

describe('options::tags', function() {

    it('set tags', function() {
        $('<div id="target" data-track="a/b/c"><a href="">test</a><img src="" alt=""><span>test</span></div>').appendTo('body');
        tracker.init({
            UA: 'test',
            tags: ['a', 'img']
        });
        expect($('#target>a').data('track')).to.be('a/b/c', '')
        expect($('#target>img').data('track')).to.be('a/b/c', '')
        expect($('#target>span').data('track')).to.be(undefined, '')
    });

    it('set tags', function() {
        $('<div id="target" data-track="a/b/c"><a href="">test</a><img src="" alt=""><span>test</span></div>').appendTo('body');
        tracker.init({
            UA: 'test',
            tags: ['a', 'img']
        });
        expect($('#target>a').data('track')).to.be('a/b/c', '');
        expect($('#target>img').data('track')).to.be('a/b/c', '');
        expect($('#target>span').data('track')).to.be(undefined, '');
    });
});

describe('preparams', function() {
    it('set preparams', function() {
        $('<a href="#" data-track="a/b/{other2}" id="target">test</a>').appendTo('body');
        tracker.setPreParams({
            'other2': 'iamother'
        });
        expect($('#target').data('track')).to.be('a/b/iamother', '中途添加自定义变量');
    });
});

it('set preparams in option', function() {
    $('<a href="#" data-track="a/b/{pre}" id="target">test</a>').appendTo('body');
    tracker.init({
        UA: 'test',
        preParams: {
            pre: 'b'
        }
    });
    expect($('#target').data('track')).to.be('a/b/b', 'should return the parsed key');
});

it('get preparam set in option', function() {
    tracker.init({
        UA: 'test',
        preParams: {
            pre: 'b'
        }
    });
    expect(tracker.getPreParam('pre')).to.be('b', 'should return the parsed key');
});

it('get preparam set with addPreParam', function() {
    tracker.setPreParams({
        'other2': 'iamother'
    });
    expect(tracker.getPreParam('other2')).to.be('iamother', 'should return iamother');
});

describe('data-track-on支持', function() {
    it('data-track-on的默认不执行统计', function() {
        $('<a href="#" data-track="a/b/{other2}" data-track-on="hello" id="target">test</a>').appendTo('body');
        tracker.addService('test1', function(key) {
            $('body').append('<span id="ghost">I am a ghost.</span>')
        });
        tracker.init({
            UA: 'test'
        });
        $('#target').click();
        expect($('#ghost').length).to.be(0);
    });

    it('data-track-on的触发自定义事件', function() {
        $('<a href="#" data-track="a/b/{other2}" data-track-on="hello" id="target">test</a>').appendTo('body');
        tracker.addService('test1', function(key) {
            $('body').append('<span id="ghost">I am a ghost.</span>')
        });
        tracker.init({
            UA: 'test'
        });
        $('#target').trigger('hello');
        expect($('#ghost').length).to.be(1);
    });
});